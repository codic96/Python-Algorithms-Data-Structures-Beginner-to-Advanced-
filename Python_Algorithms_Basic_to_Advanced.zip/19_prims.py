# Prim's MST Skeleton
def prim(graph):
    pass
