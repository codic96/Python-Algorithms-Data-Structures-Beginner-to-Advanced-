# Depth First Search
def dfs(graph, node, visited=None):
    if visited is None:
        visited = set()
    visited.add(node)
    print(node)
    for n in graph[node]:
        if n not in visited:
            dfs(graph, n, visited)
