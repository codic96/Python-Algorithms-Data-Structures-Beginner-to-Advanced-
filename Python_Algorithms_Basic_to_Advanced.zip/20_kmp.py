# KMP Pattern Matching Skeleton
def kmp_search(text, pattern):
    pass
