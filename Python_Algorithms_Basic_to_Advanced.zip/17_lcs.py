# Longest Common Subsequence
def lcs(a, b):
    dp = [[0]*(len(b)+1) for _ in range(len(a)+1)]
    return dp
