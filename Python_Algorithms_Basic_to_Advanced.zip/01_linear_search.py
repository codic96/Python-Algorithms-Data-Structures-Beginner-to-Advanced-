# Linear Search
def linear_search(arr, target):
    for i, x in enumerate(arr):
        if x == target:
            return i
    return -1
